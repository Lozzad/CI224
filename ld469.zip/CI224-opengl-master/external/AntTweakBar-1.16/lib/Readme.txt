These files are part of the AntTweakBar library.
http://anttweakbar.sourceforge.net/doc
